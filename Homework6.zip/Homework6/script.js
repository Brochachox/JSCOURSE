let cells = document.querySelectorAll(".cell");
console.log(cells);
playerFlag = 1;
